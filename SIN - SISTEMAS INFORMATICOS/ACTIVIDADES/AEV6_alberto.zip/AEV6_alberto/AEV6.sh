#!/bin/bash 

# AEV6 - Shell Scripts

# Funcion solicitar fichero 
solicitar_fichero() {
	while true; do
		read -p "Introduce el nombre del fichero de grupos a procesar: " archivo
		if [ -f "$archivo" ]; then
			break 
		else
			echo "Error, el fichero '$archivo' no existe. Intentalo de nuevo."
		fi
	done
}

# Solicitar fichero 
solicitar_fichero

# Variables para almacenar resultados 
declare -A usuarios_por_grupo
max_usuarios=0
grupos_max=()

# Procesar cada linea 
while IFS= read -r linea; do
	# Extraer nombre del grupo
	grupo="${linea%%:*}"
	# Extraer usuarios 
	usuarios="${linea#*:}"
	# Eliminar espacions en blanco y contar palabras
	usuarios="${usuarios#"${usuarios%%[![:space:]]*}"}"
	if [ -z "$usuarios" ]; then 
		num_usuarios=0
	else 
		# Contar usuarios
		num_usuarios=1
		temp="$usuarios"
		while [[ "$temp" == *" "*]]; do
			temp="${temp#* }"
			((num_usuarios++))
		done
	fi

	# Almacenar conteo
	usuarios_por_grupo["$grupo"]=$num_usuarios

	# Actualizar maximo
	if (( num_usuarios > max_usuarios )); then 
		max_usuarios=$num_usuarios
		grupos_max=("$grupo")
	elif (( num_usuarios == max_usuarios )); then 
		grupos_max+=("$grupo")
	fi
done < "$archivo"

# Mostrar resultados 
total_grupos=${#usuarios_por_grupo[@]}
echo "El fichero tiene $total_grupos grupos."
for grupo in "${!usuarios_por_grupo[@]}"; do
	echo "$grupo: ${usuarios_por_grupo[$grupo]} usuarios."
done

echo -n "El grupo con mayor numero de usuarios es: ${grupos_max[@]}."


